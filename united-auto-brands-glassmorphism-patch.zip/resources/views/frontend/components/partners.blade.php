{{-- Our Brands — Glassmorphism Section --}}
@php
    use App\Models\Brand;
    $brands = Brand::allBrands();
@endphp

<section class="brands-glass-section">
    <div class="brands-glass-bg" aria-hidden="true">
        <span class="brands-glass-orb brands-glass-orb--one"></span>
        <span class="brands-glass-orb brands-glass-orb--two"></span>
        <span class="brands-glass-orb brands-glass-orb--three"></span>
    </div>

    <div class="container">
        <div class="brands-glass-header">
            <p class="eyebrow">Multi-Brand Bosch Service</p>
            <h2>Brands We Service</h2>
            <p class="brands-glass-subtitle">Genuine-quality diagnostics, repair, and maintenance for every make we work on.</p>
        </div>

        <div class="brands-glass-grid" id="brandsGlassGrid">
            @foreach($brands as $brand)
                <div class="brand-glass-card" tabindex="0">
                    <div class="brand-glass-card__shine"></div>
                    <img
                        src="{{ asset($brand->image) }}"
                        alt="{{ $brand->name }} service at United Auto"
                        class="brand-glass-card__logo"
                        loading="lazy">
                    <span class="brand-glass-card__label">{{ $brand->name }}</span>
                </div>
            @endforeach
        </div>
    </div>
</section>

<style>
    .brands-glass-section {
        position: relative;
        overflow: hidden;
        padding: var(--space-6) 0;
        background: linear-gradient(135deg, var(--color-navy) 0%, #2a0000 45%, var(--color-primary-red-dark) 100%);
        isolation: isolate;
    }

    .brands-glass-bg {
        position: absolute;
        inset: 0;
        z-index: 0;
        overflow: hidden;
    }

    .brands-glass-orb {
        position: absolute;
        border-radius: 50%;
        filter: blur(70px);
        opacity: 0.35;
        animation: brandsOrbFloat 14s ease-in-out infinite;
    }

    .brands-glass-orb--one {
        width: 340px;
        height: 340px;
        top: -120px;
        left: -80px;
        background: var(--color-primary-red);
        animation-delay: 0s;
    }

    .brands-glass-orb--two {
        width: 260px;
        height: 260px;
        bottom: -100px;
        right: 5%;
        background: #ffffff;
        opacity: 0.12;
        animation-delay: -5s;
    }

    .brands-glass-orb--three {
        width: 200px;
        height: 200px;
        top: 30%;
        right: -60px;
        background: var(--color-primary-red-dark);
        animation-delay: -9s;
    }

    @keyframes brandsOrbFloat {
        0%, 100% { transform: translate(0, 0) scale(1); }
        50% { transform: translate(30px, -20px) scale(1.08); }
    }

    .brands-glass-header {
        position: relative;
        z-index: 1;
        text-align: center;
        margin-bottom: var(--space-5);
    }

    .brands-glass-header .eyebrow {
        justify-content: center;
        color: var(--color-primary-red);
        letter-spacing: 0.08em;
        text-transform: uppercase;
        font-weight: var(--font-weight-bold);
        font-size: var(--font-size-small);
    }

    .brands-glass-header h2 {
        color: var(--color-white);
        margin: var(--space-1) 0;
        font-family: var(--font-heading);
    }

    .brands-glass-subtitle {
        color: rgba(255, 255, 255, 0.7);
        max-width: 560px;
        margin: 0 auto;
    }

    .brands-glass-grid {
        position: relative;
        z-index: 1;
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
        gap: var(--space-3);
    }

    .brand-glass-card {
        position: relative;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: var(--space-2);
        padding: var(--space-3) var(--space-2);
        min-height: 140px;
        border-radius: var(--radius-card);
        background: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.18);
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        box-shadow: var(--shadow-card);
        overflow: hidden;
        cursor: pointer;
        transform-style: preserve-3d;
        transition: transform var(--transition-normal), background var(--transition-normal),
            border-color var(--transition-normal), box-shadow var(--transition-normal);
        will-change: transform;
    }

    .brand-glass-card__shine {
        position: absolute;
        inset: 0;
        background: radial-gradient(circle at var(--mx, 50%) var(--my, 50%), rgba(255, 255, 255, 0.35), transparent 55%);
        opacity: 0;
        transition: opacity var(--transition-fast);
        pointer-events: none;
    }

    .brand-glass-card__logo {
        max-height: 46px;
        width: auto;
        max-width: 90%;
        object-fit: contain;
        filter: grayscale(100%) brightness(0) invert(1) opacity(0.75);
        transition: filter var(--transition-normal), transform var(--transition-normal);
    }

    .brand-glass-card__label {
        font-size: var(--font-size-small);
        color: rgba(255, 255, 255, 0.55);
        font-weight: var(--font-weight-medium);
        letter-spacing: 0.02em;
        transition: color var(--transition-normal);
    }

    .brand-glass-card:hover,
    .brand-glass-card:focus-visible {
        background: rgba(255, 255, 255, 0.16);
        border-color: rgba(255, 255, 255, 0.4);
        box-shadow: 0 16px 40px rgba(0, 0, 0, 0.35);
        outline: none;
    }

    .brand-glass-card:hover .brand-glass-card__shine,
    .brand-glass-card:focus-visible .brand-glass-card__shine {
        opacity: 1;
    }

    .brand-glass-card:hover .brand-glass-card__logo,
    .brand-glass-card:focus-visible .brand-glass-card__logo {
        filter: grayscale(0%) brightness(1) invert(0) opacity(1);
        transform: scale(1.08) translateZ(20px);
    }

    .brand-glass-card:hover .brand-glass-card__label,
    .brand-glass-card:focus-visible .brand-glass-card__label {
        color: var(--color-white);
    }

    @media (prefers-reduced-motion: reduce) {
        .brand-glass-card,
        .brand-glass-card__logo,
        .brands-glass-orb {
            transition: none;
            animation: none;
        }
    }

    @media (max-width: 576px) {
        .brands-glass-grid {
            grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
            gap: var(--space-2);
        }
        .brand-glass-card {
            min-height: 110px;
        }
    }
</style>

<script>
    (function () {
        var grid = document.getElementById('brandsGlassGrid');
        if (!grid) return;
        var isTouch = window.matchMedia('(hover: none), (pointer: coarse)').matches;
        var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        if (isTouch || reduceMotion) return;

        var cards = grid.querySelectorAll('.brand-glass-card');
        cards.forEach(function (card) {
            card.addEventListener('mousemove', function (e) {
                var rect = card.getBoundingClientRect();
                var x = e.clientX - rect.left;
                var y = e.clientY - rect.top;
                var midX = rect.width / 2;
                var midY = rect.height / 2;
                var rotateX = ((y - midY) / midY) * -6;
                var rotateY = ((x - midX) / midX) * 6;
                card.style.transform = 'perspective(600px) rotateX(' + rotateX + 'deg) rotateY(' + rotateY + 'deg) translateY(-4px)';
                card.style.setProperty('--mx', (x / rect.width) * 100 + '%');
                card.style.setProperty('--my', (y / rect.height) * 100 + '%');
            });
            card.addEventListener('mouseleave', function () {
                card.style.transform = 'perspective(600px) rotateX(0deg) rotateY(0deg) translateY(0)';
            });
        });
    })();
</script>
